package com.example.demopage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoPageApplicationTests {

	@Test
	void contextLoads() {
	}

}
