package com.example.demopage;

public record ErrorResponse(String message) {

}
